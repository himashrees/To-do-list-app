document.addEventListener('DOMContentLoaded', function() {
    loadTasks();
});

function addTask() {
    const taskInput = document.getElementById('taskInput').value.trim();
    if (!taskInput) {
        alert('Please enter a Task.');
        return;
    }

    const task = {
        description: taskInput,
        completed: false
    };

    appendTaskToDOM(task);
    saveTask(task);
    document.getElementById('taskInput').value = '';
}

function toggleTaskCompletion(checkbox) {
    const taskText = checkbox.parentElement.querySelector('span.task-text'); 
    if (!taskText) {
        console.error("Task text not found!");
        return;
    }

    if (checkbox.checked) {
        taskText.classList.add('completed');
    } else {
        taskText.classList.remove('completed');
    }
    updateLocalStorage();
}

function editTask(button) {
    const newTaskDescription = prompt('Edit the task:', button.parentNode.innerText.split('Edit')[0].trim());
    if (newTaskDescription) {
        button.parentNode.childNodes[1].nodeValue = ' ' + newTaskDescription + ' ';
        updateLocalStorage();
    }
}

function deleteTask(button) {
    button.parentNode.remove();
    updateLocalStorage();
}

function saveTask(task) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.push(task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function loadTasks() {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = ''; 

    tasks.forEach(task => {
        appendTaskToDOM(task);
    });
}

function appendTaskToDOM(task) {
    const taskList = document.getElementById('taskList');
    const taskItem = document.createElement('li');
    taskItem.innerHTML = `<input type="checkbox" onchange="toggleTaskCompletion(this)" ${task.completed ? 'checked' : ''}> <span class="task-text">${task.description}</span> <button onclick="editTask(this)">Edit</button> <button onclick="deleteTask(this)">Delete</button>`;
    if (task.completed) {
        taskItem.querySelector('.task-text').classList.add('completed');
    }
    taskList.appendChild(taskItem);
}

function updateLocalStorage() {
    const tasks = [];
    document.querySelectorAll('#taskList li').forEach(task => {
        const description = task.querySelector('.task-text').innerText; 
        const completed = task.querySelector('.task-text').classList.contains('completed');
        tasks.push({ description, completed });
    });
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function showAllTasks() {
    loadTasks();
}

function showCompletedTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = ''; 

    tasks.forEach(task => {
        if (task.completed) {
            appendTaskToDOM(task);
        }
    });
}
