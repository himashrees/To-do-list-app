const gkQuestions = [
    { question: 'What is the capital of France?', options: ['a) London', 'b) Madrid', 'c) Paris'], answer: 'c' },
    { question: 'What is the largest planet in our solar system?', options: ['a) Jupiter', 'b) Saturn', 'c) Mars'], answer: 'a' },
    { question: 'Who wrote "Romeo and Juliet"?', options: ['a) Charles Dickens', 'b) William Shakespeare', 'c) Jane Austen'], answer: 'b' },
    { question: 'What is the currency of Japan?', options: ['a) Yen', 'b) Yuan', 'c) Euro'], answer: 'a' },
    { question: 'Which organ is responsible for filtering blood?', options: ['a) Liver', 'b) Kidney', 'c) Heart'], answer: 'b' }
  ];
  
  // Populate General Knowledge Questions
  const gkQuestionDiv = document.getElementById('gkQuestions');
  for (let i = 0; i < gkQuestions.length; i++) {
    const question = gkQuestions[i];
    gkQuestionDiv.innerHTML += `<div>${i + 1}. ${question.question}</div>`;
    for (let option of question.options) {
      gkQuestionDiv.innerHTML += `<input type="radio" name="gkq${i + 1}" value="${option.split(')')[0]}"> ${option}<br>`;
    }
  }
  
  document.getElementById('gkQuizForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    let score = 0;
    for (let i = 0; i < gkQuestions.length; i++) {
      const answer = gkQuestions[i].answer;
      const selectedOption = document.querySelector(`input[name="gkq${i + 1}"]:checked`);
      if (selectedOption && selectedOption.value === answer) {
        score++;
      }
    }
    
    const totalQuestions = gkQuestions.length;
    const result = `You scored ${score} out of ${totalQuestions} in the General Knowledge Quiz.`;
    document.getElementById('result').innerText = result;
  });
  