 

document.addEventListener('DOMContentLoaded', function () {
    const mathQuizForm = document.getElementById('mathQuizForm');
    const mathQuestions = [
        { question: 'What is 2 + 2?', options: ['a) 3', 'b) 4', 'c) 5'], answer: 'b' },
        { question: 'What is 10 - 5?', options: ['a) 3', 'b) 5', 'c) 10'], answer: 'b' },
        { question: 'What is 3 x 4?', options: ['a) 10', 'b) 11', 'c) 12'], answer: 'c' },
        { question: 'What is 15 ÷ 3?', options: ['a) 3', 'b) 4', 'c) 5'], answer: 'c' },
        { question: 'What is 8 + 7?', options: ['a) 14', 'b) 15', 'c) 16'], answer: 'b' }
    ];

    const mathQuestionDiv = document.getElementById('mathQuestions');
    for (let i = 0; i < mathQuestions.length; i++) {
        const question = mathQuestions[i];
        mathQuestionDiv.innerHTML += `<div>${i + 1}. ${question.question}</div>`;
        
        for (let option of question.options) {
            mathQuestionDiv.innerHTML += `<label><input type="radio" name="mq${i + 1}" value="${option.split(')')[0]}"> ${option}</label><br>`;
        }
        mathQuestionDiv.innerHTML += `<span id="correctAnswer${i + 1}" class="correct-answer">Correct Answer: ${question.answer}</span><br><br>`;
    }

    mathQuizForm.addEventListener('submit', function(e) {
        e.preventDefault();
        let score = 0;
        for (let i = 0; i < mathQuestions.length; i++) {
            const answer = mathQuestions[i].answer;
            const selectedOption = document.querySelector(`input[name="mq${i + 1}"]:checked`);
            
            if (selectedOption) {
                const questionDiv = selectedOption.parentElement;
                if (selectedOption.value === answer) {
                    questionDiv.style.color = 'green';
                    score++;
                } else {
                    questionDiv.style.color = 'red';
                    const correctAnswerElement = document.getElementById(`correctAnswer${i + 1}`);
                    if (correctAnswerElement) {
                        correctAnswerElement.style.display = 'inline';
                    }
                }
            }
        }
        const resultElement = document.getElementById('result');
        if (resultElement) {
            resultElement.innerText = `You scored ${score} out of ${mathQuestions.length} in the Math Quiz.`;
            resultElement.classList.add('show');
        }
    });
});





