document.addEventListener('DOMContentLoaded', (event) => {
    // Event listener for Signup button
    document.getElementById('signupButton').addEventListener('click', function() {
      // Hide the login form and display the signup form
      document.getElementById('loginFormDiv').style.display = 'none';
      document.getElementById('signupFormDiv').style.display = 'block';
    });
  
    // Event listener for Login form submission
    document.getElementById('loginForm').addEventListener('submit', function(e) {
      e.preventDefault();
  
      const loginEmail = document.getElementById('loginEmail').value;
      const loginPassword = document.getElementById('loginPassword').value;
  
      // Implement your login validation logic here
      if (loginEmail.trim() === '' || loginPassword.trim() === '') {
        alert('Please enter valid login credentials.');
        return;
      }
  
      // Redirect to the next page or perform further actions
      window.location.href = 'quizSelection.html';
    });
  
    // Event listener for Signup form submission
    document.getElementById('signupForm').addEventListener('submit', function(e) {
      e.preventDefault();
  
      const signupName = document.getElementById('signupName').value;
      const signupEmail = document.getElementById('signupEmail').value;
      const signupPassword = document.getElementById('signupPassword').value;
  
      // Validate the signup inputs
      if (signupName.trim() === '' || signupEmail.trim() === '' || signupPassword.trim() === '') {
        alert('Please fill out all the signup fields.');
        return;
      }
  
      // Redirect to the next page or perform further actions
      window.location.href = 'quizSelection.html';
    });
  });
  