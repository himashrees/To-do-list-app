// Math Questions
const mathQuestions = [
    { question: 'What is 2 + 2?', options: ['a) 3', 'b) 4', 'c) 5'], answer: 'b' },
    { question: 'What is 10 - 5?', options: ['a) 3', 'b) 5', 'c) 10'], answer: 'b' }
  ];
  
  // General Knowledge Questions
  const gkQuestions = [
    { question: 'What is the capital of France?', options: ['a) London', 'b) Madrid', 'c) Paris'], answer: 'c' },
    { question: 'What is the largest planet in our solar system?', options: ['a) Jupiter', 'b) Saturn', 'c) Mars'], answer: 'a' }
  ];
  
  // Populate Math Questions
  const mathQuestionDiv = document.getElementById('mathQuestions');
  mathQuestionDiv.innerHTML = '<h3>Math Quiz</h3>';
  for (let i = 0; i < mathQuestions.length; i++) {
    const question = mathQuestions[i];
    mathQuestionDiv.innerHTML += `<div>${i + 1}. ${question.question}</div>`;
    for (let option of question.options) {
      mathQuestionDiv.innerHTML += `<input type="radio" name="mq${i + 1}" value="${option.split(')')[0]}"> ${option}<br>`;
    }
  }
  
  // Populate General Knowledge Questions
  const gkQuestionDiv = document.getElementById('gkQuestions');
  gkQuestionDiv.innerHTML = '<h3>General Knowledge Quiz</h3>';
  for (let i = 0; i < gkQuestions.length; i++) {
    const question = gkQuestions[i];
    gkQuestionDiv.innerHTML += `<div>${i + 1}. ${question.question}</div>`;
    for (let option of question.options) {
      gkQuestionDiv.innerHTML += `<input type="radio" name="gkq${i + 1}" value="${option.split(')')[0]}"> ${option}<br>`;
    }
  }
  
  // Submission and Evaluation Logic
  document.getElementById('mathQuizForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let mathScore = 0;
    for (let i = 0; i < mathQuestions.length; i++) {
      const answer = mathQuestions[i].answer;
      const selectedAnswer = document.querySelector(`input[name=mq${i + 1}]:checked`);
      if (selectedAnswer && selectedAnswer.value === answer) {
        mathScore++;
      }
    }
    document.getElementById('result').innerHTML = `Math Quiz: You scored ${mathScore} out of ${mathQuestions.length}.<br>`;
  });
  
  document.getElementById('gkQuizForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let gkScore = 0;
    for (let i = 0; i < gkQuestions.length; i++) {
      const answer = gkQuestions[i].answer;
      const selectedAnswer = document.querySelector(`input[name=gkq${i + 1}]:checked`);
      if (selectedAnswer && selectedAnswer.value === answer) {
        gkScore++;
      }
    }
    document.getElementById('result').innerHTML += `General Knowledge Quiz: You scored ${gkScore} out of ${gkQuestions.length}.`;
  });
  